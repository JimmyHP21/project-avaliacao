create
    definer = root@localhost procedure sp_comment_save(IN pcomment varchar(255), IN pdestaque tinyint,
                                                       IN pdestaquevalue int, IN pidpost int, IN piduser int)
BEGIN

  INSERT INTO tb_comments (commentvalue, destaquecomment, valuedestaque, idpost, iduser)
        VALUES(pcomment, pdestaque, pdestaquevalue, pidpost, piduser);

  SELECT * FROM tb_comments  WHERE idcomment = LAST_INSERT_ID();

END;

