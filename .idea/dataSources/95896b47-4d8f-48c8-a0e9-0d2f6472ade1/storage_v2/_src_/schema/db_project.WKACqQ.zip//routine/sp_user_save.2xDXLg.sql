create
    definer = root@localhost procedure sp_user_save(IN pdesname varchar(255), IN pdeslogin varchar(64),
                                                    IN pdespassword varchar(256), IN pbalance int,
                                                    IN passinature tinyint)
BEGIN

  INSERT INTO tb_users (desname, deslogin, despassword, balance, signature)
        VALUES(pdesname, pdeslogin, pdespassword, pbalance, passinature);

  SELECT * FROM tb_users  WHERE iduser = LAST_INSERT_ID();

END;

