create
    definer = root@localhost procedure sp_comment_update(IN pidcomment int, IN pcomment varchar(255),
                                                         IN pdestaque tinyint, IN pdestaquevalue int, IN pidpost int,
                                                         IN piduser int)
BEGIN

  UPDATE tb_comments
      SET commentvalue = pcomment,
          destaquecomment = pdestaque,
          valuedestaque = pdestaquevalue,
          idpost = pidpost,
          iduser = piduser
    WHERE idcomment = pidcomment;

  SELECT * FROM tb_comments  WHERE idcomment = pidcomment;

END;

