create
    definer = root@localhost procedure sp_post_update(IN pidpost int, IN pdescription varchar(255), IN ptype tinyint,
                                                      IN piduser int)
BEGIN

  UPDATE tb_posts
      SET description = pdescription,
          type = ptype,
          iduser = piduser
    WHERE idpost = pidpost;

  SELECT * FROM tb_posts  WHERE idpost = pidpost;

END;

