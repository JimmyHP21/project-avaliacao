create
    definer = root@localhost procedure sp_users_save(IN pdesname varchar(64), IN pdeslogin varchar(64),
                                                     IN pdespassword varchar(256))
BEGIN

  INSERT INTO tb_users (desname, deslogin, despassword)
    VALUES(pdesname, pdeslogin, pdespassword);

  SELECT * FROM tb_users  WHERE iduser = LAST_INSERT_ID();

END;

