create
    definer = root@localhost procedure sp_user_update(IN piduser int, IN pdesname varchar(255),
                                                      IN pdeslogin varchar(64), IN pdespassword varchar(256),
                                                      IN pbalance int, IN psignature tinyint)
BEGIN

    UPDATE tb_users
    SET
        desname = pdesname,
        deslogin = pdeslogin,
        despassword = pdespassword,
        balance = pbalance,
        signature = psignature
  WHERE iduser = piduser;

    SELECT * FROM tb_users WHERE iduser = piduser;

END;

