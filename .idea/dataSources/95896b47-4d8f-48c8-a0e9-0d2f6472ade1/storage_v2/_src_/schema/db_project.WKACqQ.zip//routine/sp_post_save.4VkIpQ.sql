create
    definer = root@localhost procedure sp_post_save(IN pdescription varchar(255), IN ptype tinyint, IN piduser int)
BEGIN

  INSERT INTO tb_posts (description, type, iduser)
        VALUES(pdescription, ptype, piduser);

  SELECT * FROM tb_posts  WHERE idpost = LAST_INSERT_ID();

END;

